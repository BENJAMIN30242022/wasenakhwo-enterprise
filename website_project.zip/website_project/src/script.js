/wasenakhwo-enterprise
├── index.html                # Homepage
├── about.html                # About Us page
├── services.html             # Services page
├── projects.html             # Projects page
├── contact.html              # Contact page
├── /css
│   └── styles.css            # CSS file for styling
└── /js
    └── script.js             # JavaScript for interactivity
// Example: A simple script to change the background color on click
document.body.addEventListener('click', () => {
  document.body.style.backgroundColor = 'lightblue';
});
cd path/to/wasenakhwo-enterprise
git init
